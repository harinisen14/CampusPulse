# CampusPulse

AI-powered campus app: report issues with a photo, upvote, track fixes, and find lost items.

## Setup
1. Create a Firebase project: enable **Google Auth**, **Firestore**, **Storage**.
2. `cp .env.example .env` and fill the values (+ Gemini key from aistudio.google.com).
3. `npm install && npm run dev`
4. Deploy rules: `firebase deploy --only firestore:rules,storage`
5. Make an admin: in Firestore create `admins/<your-uid>` (any field).

## Why it is fast & efficient
- Images compressed in the browser (about 800px, JPEG 70%) before upload and AI call
- Upload and AI analysis run in parallel
- Realtime listeners capped with `limit(30)`
- One upvote per user enforced by Firestore rules (atomic `increment`)
- Lost/Found matching by tag overlap: free and instant
- AI failure falls back to defaults, so the app never breaks

## Production note
Gemini key is in the client for hackathon speed. For production, move `analyze()` to a Cloud Function.
