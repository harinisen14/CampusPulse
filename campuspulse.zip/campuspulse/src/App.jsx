import { useEffect, useMemo, useState } from "react";
import { onAuthStateChanged, signInWithPopup, signOut } from "firebase/auth";
import {
  collection, query, orderBy, limit, onSnapshot, addDoc, updateDoc,
  doc, getDoc, arrayUnion, increment, serverTimestamp,
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { auth, db, storage, provider } from "./firebase";
import { prepImage, analyze, findMatches } from "./utils";
import "./App.css";

const STATUSES = ["Pending", "In Progress", "Fixed"];

// One realtime listener per collection, capped for speed (pagination-ready).
function useCol(name, field, n = 30) {
  const [rows, setRows] = useState([]);
  useEffect(
    () => onSnapshot(query(collection(db, name), orderBy(field, "desc"), limit(n)),
      (s) => setRows(s.docs.map((d) => ({ id: d.id, ...d.data() })))),
    [name, field, n]
  );
  return rows;
}

function PostForm({ kind, user, onDone }) {
  const [file, setFile] = useState(null);
  const [text, setText] = useState("");
  const [loc, setLoc] = useState("");
  const [type, setType] = useState("lost");
  const [anon, setAnon] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (!file || !text.trim() || busy) return;
    setBusy(true);
    try {
      const { blob, b64 } = await prepImage(file);
      const [ai, imageUrl] = await Promise.all([
        analyze(kind === "issue" ? "issue" : "item", b64, text),
        (async () => {
          const r = ref(storage, `uploads/${user.uid}/${Date.now()}.jpg`);
          await uploadBytes(r, blob);
          return getDownloadURL(r);
        })(),
      ]);
      const base = { text, location: loc, imageUrl, uid: user.uid, createdAt: serverTimestamp(), ...ai };
      if (kind === "issue")
        await addDoc(collection(db, "issues"), { ...base, status: "Pending", upvotes: 0, voters: [], anonymous: anon });
      else await addDoc(collection(db, "lostfound"), { ...base, type, status: "Open" });
      setFile(null); setText(""); setLoc("");
      onDone?.();
    } catch (err) {
      alert("Failed: " + err.message);
    }
    setBusy(false);
  };

  return (
    <form className="card" onSubmit={submit}>
      {kind === "item" && (
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="lost">I lost something</option>
          <option value="found">I found something</option>
        </select>
      )}
      <input type="file" accept="image/*" capture="environment" onChange={(e) => setFile(e.target.files[0])} />
      <input placeholder="Location (e.g. Block A, Room 204)" value={loc} onChange={(e) => setLoc(e.target.value)} />
      <textarea placeholder="Describe it..." value={text} onChange={(e) => setText(e.target.value)} />
      {kind === "issue" && (
        <label><input type="checkbox" checked={anon} onChange={(e) => setAnon(e.target.checked)} /> Post anonymously</label>
      )}
      <button disabled={busy || !file}>{busy ? "AI is analysing..." : "Submit"}</button>
    </form>
  );
}

function IssueCard({ i, user, admin }) {
  const voted = i.voters?.includes(user.uid);
  const upvote = () =>
    updateDoc(doc(db, "issues", i.id), { upvotes: increment(1), voters: arrayUnion(user.uid) });
  const setStatus = (status) => updateDoc(doc(db, "issues", i.id), { status });
  return (
    <div className="card">
      <img src={i.imageUrl} loading="lazy" alt="" />
      <div className="row">
        <span className={`tag ${i.urgency}`}>{i.urgency}</span>
        <span className="tag">{i.category}</span>
        <span className={`tag s-${i.status.replace(" ", "")}`}>{i.status}</span>
      </div>
      <p><b>{i.summary}</b></p>
      <p className="muted">{i.text} · {i.location} · {i.anonymous ? "Anonymous" : "Student"}</p>
      <div className="row">
        <button disabled={voted} onClick={upvote}>▲ {i.upvotes}</button>
        {admin && (
          <select value={i.status} onChange={(e) => setStatus(e.target.value)}>
            {STATUSES.map((s) => <option key={s}>{s}</option>)}
          </select>
        )}
      </div>
    </div>
  );
}

function LostFound({ user }) {
  const items = useCol("lostfound", "createdAt");
  const mine = items.filter((x) => x.uid === user.uid && x.status === "Open");
  const resolve = (id) => updateDoc(doc(db, "lostfound", id), { status: "Returned" });
  return (
    <>
      <PostForm kind="item" user={user} />
      {items.filter((x) => x.status === "Open").map((x) => {
        const matches = mine.some((m) => m.id === x.id) ? findMatches(x, items) : [];
        return (
          <div className="card" key={x.id}>
            <img src={x.imageUrl} loading="lazy" alt="" />
            <span className={`tag ${x.type}`}>{x.type.toUpperCase()}</span>
            <p><b>{x.summary}</b></p>
            <p className="muted">{x.location}</p>
            {matches.length > 0 && (
              <div className="match">🔔 Possible match: {matches.map((m) => `${m.summary} (${m.location})`).join(" | ")}</div>
            )}
            {x.uid === user.uid && <button onClick={() => resolve(x.id)}>Mark returned</button>}
          </div>
        );
      })}
    </>
  );
}

export default function App() {
  const [user, setUser] = useState(undefined);
  const [admin, setAdmin] = useState(false);
  const [tab, setTab] = useState("issues");
  const [showForm, setShowForm] = useState(false);
  const issues = useCol("issues", "upvotes");

  useEffect(() => onAuthStateChanged(auth, async (u) => {
    setUser(u);
    setAdmin(u ? (await getDoc(doc(db, "admins", u.uid))).exists() : false);
  }), []);

  const stats = useMemo(() => {
    const fixed = issues.filter((i) => i.status === "Fixed").length;
    return { total: issues.length, fixed, pct: issues.length ? Math.round((fixed / issues.length) * 100) : 0 };
  }, [issues]);

  if (user === undefined) return <p className="center">Loading...</p>;
  if (!user)
    return (
      <div className="center">
        <h1>CampusPulse</h1>
        <p>Report. Upvote. Get it fixed.</p>
        <button onClick={() => signInWithPopup(auth, provider)}>Sign in with Google</button>
      </div>
    );

  return (
    <div className="app">
      <header>
        <h2>CampusPulse</h2>
        <button className="ghost" onClick={() => signOut(auth)}>Logout</button>
      </header>
      <nav>
        {["issues", "lostfound", ...(admin ? ["admin"] : [])].map((t) => (
          <button key={t} className={tab === t ? "on" : ""} onClick={() => setTab(t)}>
            {t === "lostfound" ? "Lost & Found" : t[0].toUpperCase() + t.slice(1)}
          </button>
        ))}
      </nav>

      {tab === "issues" && (
        <>
          <button className="fab" onClick={() => setShowForm(!showForm)}>{showForm ? "Close" : "+ Report issue"}</button>
          {showForm && <PostForm kind="issue" user={user} onDone={() => setShowForm(false)} />}
          {issues.map((i) => <IssueCard key={i.id} i={i} user={user} admin={false} />)}
        </>
      )}
      {tab === "lostfound" && <LostFound user={user} />}
      {tab === "admin" && admin && (
        <>
          <div className="stats">
            <div><b>{stats.total}</b>Total</div>
            <div><b>{stats.fixed}</b>Fixed</div>
            <div><b>{stats.pct}%</b>Resolved</div>
          </div>
          {issues.map((i) => <IssueCard key={i.id} i={i} user={user} admin />)}
        </>
      )}
    </div>
  );
}
