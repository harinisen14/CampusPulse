// Compress image in the browser: fast upload, cheap AI call, small storage.
export function prepImage(file, max = 800, quality = 0.7) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = img.width * s;
      c.height = img.height * s;
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(img.src);
      c.toBlob(
        (blob) => {
          const r = new FileReader();
          r.onload = () => resolve({ blob, b64: r.result.split(",")[1] });
          r.readAsDataURL(blob);
        },
        "image/jpeg",
        quality
      );
    };
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}

const MODEL = "gemini-2.5-flash";
const PROMPTS = {
  issue: `You triage college campus problems. Look at the photo and note. Reply ONLY JSON:
{"category":"Electrical|Water|WiFi|Furniture|Cleanliness|Other","urgency":"Low|Medium|High","summary":"max 10 words"}`,
  item: `You catalog lost/found items. Reply ONLY JSON:
{"tags":["3-6 lowercase words: item type, color, brand, material"],"summary":"max 10 words"}`,
};

// Falls back to safe defaults so the app never breaks if AI fails.
export async function analyze(kind, b64, text) {
  const fallback = kind === "issue"
    ? { category: "Other", urgency: "Medium", summary: text.slice(0, 60) }
    : { tags: text.toLowerCase().split(/\W+/).filter((w) => w.length > 2).slice(0, 6), summary: text.slice(0, 60) };
  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${import.meta.env.VITE_GEMINI_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${PROMPTS[kind]}\nNote: ${text}` }, { inline_data: { mime_type: "image/jpeg", data: b64 } }] }],
          generationConfig: { responseMimeType: "application/json", temperature: 0.2 },
        }),
      }
    );
    const j = await res.json();
    return { ...fallback, ...JSON.parse(j.candidates[0].content.parts[0].text) };
  } catch {
    return fallback;
  }
}

// Lost <-> Found matching by tag overlap (free, instant, no extra AI calls).
export function findMatches(item, all) {
  const mine = new Set(item.tags || []);
  return all
    .filter((o) => o.type !== item.type && o.status === "Open")
    .map((o) => ({ o, score: (o.tags || []).filter((t) => mine.has(t)).length }))
    .filter((m) => m.score >= 2)
    .sort((a, b) => b.score - a.score)
    .slice(0, 2)
    .map((m) => m.o);
}
